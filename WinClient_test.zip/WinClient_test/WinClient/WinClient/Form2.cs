﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinClient
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text != "")
            {
                Form1 frm = new Form1(textBox1.Text, "Chat");
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("You did not type your nickname!");
            }
        }
    }
}
